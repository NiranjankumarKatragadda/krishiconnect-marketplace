import '@testing-library/jest-dom/jest-globals'
global.CSS = {supports: () => false}
